BESHOY HABIB — GITHUB PAGES UPLOAD

Repository:
beshoyhabib21/beshoyhabib21.github.io

Upload these FOUR website files to the ROOT of the repository:
- index.html
- profile.jpg
- resume.html
- Beshoy_Habib_Resume.pdf

GitHub:
1. Open the repository.
2. Click Add file > Upload files.
3. Drag the four files above into GitHub.
4. Click Commit changes.

Your expected website address:
https://beshoyhabib21.github.io

If the site does not appear after the upload:
Settings > Pages > Build and deployment > Source: Deploy from a branch
Branch: main
Folder: / (root)
Then Save.

Do not upload this README_UPLOAD.txt file if you do not want it visible in the repository.
